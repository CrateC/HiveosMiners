cd /root/work/claymore && ./startup
