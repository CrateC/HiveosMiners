#!/bin/ bash

cp $(locate libssl.so.1.1) /lib/x86_64-linux-gnu/
cp $(locate libcrypto.so.1.1) /lib/x86_64-linux-gnu/
cp $(locate libmicrohttpd.so.12) /lib/x86_64-linux-gnu/
cp $(locate libhwloc.so.5) /lib/x86_64-linux-gnu/
cp $(locate libdl.so.2) /lib/x86_64-linux-gnu/
