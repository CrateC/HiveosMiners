#!/usr/bin/env bash
# This code is included in /hive/bin/custom function

. colors
. h-manifest.conf
#DWAL="dummy"
#WORKER_NAME=""
#CUSTOM_TEMPLATE=%WALLET%
#CUSTOM_URL=swap2.luckypool.io:4477
#CUSTOM_PASS=%WORKER_NAME%
#CUSTOM_ALGO="cuckaroo29s"
#CUSTOM_CONFIG_FILENAME="/hive/miners/custom/${CUSTOM_NAME}/config.xml"

[[ -z $CUSTOM_TEMPLATE ]] && echo -e "${YELLOW}CUSTOM_TEMPLATE is empty${NOCOLOR}" && return 1
[[ -z $CUSTOM_URL ]] && echo -e "${YELLOW}CUSTOM_URL is empty${NOCOLOR}" && return 1

conf="<?xml version=\"1.0\" encoding=\"utf-8\"?>
<Config xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\">
  <PrimaryConnection>
    <ConnectionAddress>swap2.luckypool.io</ConnectionAddress>
    <ConnectionPort>4477</ConnectionPort>
    <Ssl>false</Ssl>
    <Login>fh4C37BaQHYXTViA3Gi1hiLChUHS5QfLJ7uCdxGaAF2CQNTaWXtUppAe8NGa9KvLdTSbu5NFztzPVgtTzHyxv7Ln1qow7fWQ2</Login>
    <Password>${CUSTOM_PASS}</Password>
  </PrimaryConnection>
  <SecondaryConnection>
    <ConnectionAddress>swap2.luckypool.io</ConnectionAddress>
    <ConnectionPort>4488</ConnectionPort>
    <Ssl>false</Ssl>
    <Login>fh4C37BaQHYXTViA3Gi1hiLChUHS5QfLJ7uCdxGaAF2CQNTaWXtUppAe8NGa9KvLdTSbu5NFztzPVgtTzHyxv7Ln1qow7fWQ2</Login>
    <Password>${CUSTOM_PASS}</Password>
  </SecondaryConnection>
  <LogOptions>
    <FileMinimumLogLevel>WARNING</FileMinimumLogLevel>
    <ConsoleMinimumLogLevel>INFO</ConsoleMinimumLogLevel>
    <KeepDays>1</KeepDays>
    <DisableLogging>false</DisableLogging>
  </LogOptions>
  <ReconnectToPrimary>0</ReconnectToPrimary>
  <CPUOffloadValue>0</CPUOffloadValue>
  <GPUOptions>
    <GPUOption>
      <GPUName>Ellesmere</GPUName>
      <GPUType>AMD</GPUType>
      <DeviceID>0</DeviceID>
      <PlatformID>0</PlatformID>
      <Enabled>true</Enabled>
    </GPUOption>
    <GPUOption>
      <GPUName>Ellesmere</GPUName>
      <GPUType>AMD</GPUType>
      <DeviceID>1</DeviceID>
      <PlatformID>0</PlatformID>
      <Enabled>true</Enabled>
    </GPUOption>
    <GPUOption>
      <GPUName>Ellesmere</GPUName>
      <GPUType>AMD</GPUType>
      <DeviceID>2</DeviceID>
      <PlatformID>0</PlatformID>
      <Enabled>true</Enabled>
    </GPUOption>
    <GPUOption>
      <GPUName>Ellesmere</GPUName>
      <GPUType>AMD</GPUType>
      <DeviceID>3</DeviceID>
      <PlatformID>0</PlatformID>
      <Enabled>true</Enabled>
    </GPUOption>
    <GPUOption>
      <GPUName>Ellesmere</GPUName>
      <GPUType>AMD</GPUType>
      <DeviceID>4</DeviceID>
      <PlatformID>0</PlatformID>
      <Enabled>true</Enabled>
    </GPUOption>
    <GPUOption>
      <GPUName>Ellesmere</GPUName>
      <GPUType>AMD</GPUType>
      <DeviceID>5</DeviceID>
      <PlatformID>0</PlatformID>
      <Enabled>true</Enabled>
    </GPUOption>
  </GPUOptions>
</Config>"

#replace tpl values in whole file
[[ -z $EWAL && -z $ZWAL && -z $DWAL ]] && echo -e "${RED}No WAL address is set${NOCOLOR}"
[[ ! -z $EWAL ]] && conf=$(sed "s/%EWAL%/$EWAL/g" <<< "$conf") #|| echo "${RED}EWAL not set${NOCOLOR}"
[[ ! -z $DWAL ]] && conf=$(sed "s/%DWAL%/$DWAL/g" <<< "$conf") #|| echo "${RED}DWAL not set${NOCOLOR}"
[[ ! -z $ZWAL ]] && conf=$(sed "s/%ZWAL%/$ZWAL/g" <<< "$conf") #|| echo "${RED}ZWAL not set${NOCOLOR}"
[[ ! -z $EMAIL ]] && conf=$(sed "s/%EMAIL%/$EMAIL/g" <<< "$conf")
[[ ! -z $WORKER_NAME ]] && conf=$(sed "s/%WORKER_NAME%/$WORKER_NAME/g" <<< "$conf") #|| echo "${RED}WORKER_NAME not set${NOCOLOR}"

[[ -z $CUSTOM_CONFIG_FILENAME ]] && echo -e "${RED}No CUSTOM_CONFIG_FILENAME is set${NOCOLOR}" && return 1
echo "$conf" > $CUSTOM_CONFIG_FILENAME
