#!/usr/bin/env bash
cd `dirname $0`

./xmrigDaemon-amd --config=/hive/miners/custom/xmrigccamd/config.json
